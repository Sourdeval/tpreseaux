package fr.ensisa.darcel.buoys.config.model;

public enum Usage {
	UNUSED,
	READY,
	WORKING,
	BACK,

}
