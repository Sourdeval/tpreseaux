package fr.ensisa.darcel.buoys.server.model;

public enum Usage {
	UNUSED,
	READY,
	WORKING,
	BACK,

}
